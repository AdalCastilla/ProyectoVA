# rail_human_platform > 2025-01-03 2:34pm
https://universe.roboflow.com/lin-justin/rail_human_platform

Provided by a Roboflow user
License: CC BY 4.0

